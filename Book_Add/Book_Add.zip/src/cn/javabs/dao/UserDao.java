package cn.javabs.dao;

import cn.javabs.entity.User;

public interface UserDao {
    int addUser(User u);
}
